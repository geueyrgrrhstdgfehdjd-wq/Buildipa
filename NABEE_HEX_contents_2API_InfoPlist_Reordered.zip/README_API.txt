NABEE HEX - APP CONTENTS + API CONFIG

This archive contains the files INSIDE NABEE HEX.app, not the .app folder itself.

ORIGINAL CATALOG APIs found in the supplied compiled binary:
- https://proxynabee.pro/nabeehex/api/public-catalog.php
- https://proxynabee.pro/nabeehex/api/session-check.php
- https://proxynabee.pro/nabeehex/api/app-config.php

LICENSE SERVER:
- Admin: https://cracknabee.onrender.com/admin
- Verify API: https://cracknabee.onrender.com/api/keys/verify
- Activate API: https://cracknabee.onrender.com/api/keys/activate
- Legacy: https://cracknabee.onrender.com/l

IMPORTANT:
The /admin URL is the administration web page. It is not itself the key-check API.
For an app key check, use /api/keys/verify?key=YOUR_KEY.

The supplied NABEE HEX executable is compiled. This archive updates the API
configuration/documentation files but does not claim to patch or rebuild the
Mach-O executable without the original Xcode source project.
